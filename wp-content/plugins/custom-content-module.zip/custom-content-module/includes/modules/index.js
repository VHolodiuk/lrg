// Internal Dependencies
import Inspiration from './Inspiration/Inspiration';
import Restaurant from './Restaurant/Restaurant';

export default [
    Inspiration,
    Restaurant,
];