// External Dependencies
import React, { Component, Fragment } from 'react';

// Internal Dependencies
import './style.css';


class Inspiration extends Component {

    static slug = 'simp_our_inspiration';

    render() {
        return (
            <Fragment>
                <h2 className="our-inspiration-heading">{this.props.heading}</h2>
                <div className="our-inspiration-descr">{this.props.description}</div>
                <div className="inspiration-column-wrap">
                    <div className="inspiration-column">
                        {this.props.first_column_text}
                    </div>
                    <div className="inspiration-column">
                        {this.props.second_column_text}
                    </div>
                </div>
            </Fragment>
        );
    }
}

export default Inspiration;