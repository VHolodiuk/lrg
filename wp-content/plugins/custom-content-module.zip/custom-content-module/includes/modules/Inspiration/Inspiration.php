<?php

class SIMP_OurInspiration extends ET_Builder_Module {

	public $slug       = 'simp_our_inspiration';
	public $vb_support = 'on';

	protected $module_credits = array(
    	'module_uri' => '',
    	'author'     => 'UkieWeb',
    	'author_uri' => 'https://ukieweb.com/',
    );

	public function init() {
		$this->name = esc_html__( 'Our Inspiration', 'simp-our-inspiration' );
	}

	public function get_fields() {
		return array(
			'heading'     => array(
				'label'           => esc_html__( 'Heading', 'simp-our-inspiration' ),
				'type'            => 'text',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'Input your desired heading here.', 'simp-our-inspiration' ),
				'toggle_slug'     => 'main_content',
			),
			'description'     => array(
				'label'           => esc_html__( 'Description', 'simp-our-inspiration' ),
				'type'            => 'tiny_mce',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'Content entered here will appear below the heading text.', 'simp-our-inspiration' ),
				'toggle_slug'     => 'main_content',
			),
			'first_column_text'     => array(
				'label'           => esc_html__( 'First column text', 'simp-our-inspiration' ),
				'type'            => 'tiny_mce',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'Content entered here will appear in first column.', 'simp-our-inspiration' ),
				'toggle_slug'     => 'main_content',
			),
			'second_column_text'     => array(
				'label'           => esc_html__( 'Second column text', 'simp-our-inspiration' ),
				'type'            => 'tiny_mce',
				'option_category' => 'basic_option',
				'description'     => esc_html__( 'Content entered here will appear in second column.', 'simp-our-inspiration' ),
				'toggle_slug'     => 'main_content',
			),
		);
	}


	public function render( $unprocessed_props, $content = null, $render_slug ) {
		return sprintf(
			'<h2 class="our-inspiration-heading">%1$s</h2>
			<div class="our-inspiration-descr">%2$s</div>
			<div class="inspiration-column-wrap">
			    <div class="inspiration-column">
			        %3$s
			    </div>
			    <div class="inspiration-column">
                    %4$s
                </div>
			</div>',
			esc_html($this->props['heading'] ),
			$this->props['description'],
			$this->props['first_column_text'],
			$this->props['second_column_text']
		);
	}
}

new SIMP_OurInspiration;
