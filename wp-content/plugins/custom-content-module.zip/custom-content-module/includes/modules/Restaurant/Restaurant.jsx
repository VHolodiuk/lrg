// External Dependencies
import React, { Component, Fragment } from 'react';

// Internal Dependencies
import './style.css';


class Restaurant extends Component {

    static slug = 'simp_restaurant';

    render() {
        return (
            <Fragment>
                content from specific filds
            </Fragment>
        );
    }
}

export default Restaurant;
