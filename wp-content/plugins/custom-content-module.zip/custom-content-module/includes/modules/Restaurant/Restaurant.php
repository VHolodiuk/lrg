<?php

class SIMP_Restaurant extends ET_Builder_Module {

	public $slug       = 'simp_restaurant';
	public $vb_support = 'on';

	protected $module_credits = array(
    	'module_uri' => '',
    	'author'     => 'UkieWeb',
    	'author_uri' => 'https://ukieweb.com/',
    );

	public function init() {
		$this->name = esc_html__( 'Restaurant', 'simp_restaurant' );
	}

	public function get_fields() {
    		return array();
    	}




	public function render( $unprocessed_props, $content = null, $render_slug ) {
	    $res = '';
	    //$front_page_id = get_option( 'page_on_front' );
	    //get_field('copyright_text_footer')
	    $res .= '<div class="accoordion-wrap">';
        if( have_rows('accordion_resporaunt') ):

            while( have_rows('accordion_resporaunt') ) : the_row();

                $res .= '<div class="accordion-item">';
                    $res .= '<div class="accordion-title-wrap">';
                        $res .= '<img class="accordion-title-image" src="'.get_sub_field('image_item').'" />';
                        $res .= '<div class="accordion-title-text-wrap">';
                            $res .= '<h3>'.get_sub_field('title_item').'</h3>';
                            $res .= '<p>'.get_sub_field('subtitle_line_1').'</p>';
                            $res .= '<p>'.get_sub_field('subtitle_line_2').'</p>';
                        $res .= '</div>';
                        $res .= '<img class="toggle-accordion" src="'.get_stylesheet_directory_uri().'/assets/img/accordion-plus.png" />';
                    $res .= '</div>';
                    $res .= '<div class="accordion-content-wrap">';
                        $res .= '<div class="content-text">'.get_sub_field('text_item').'</div>';
                        $res .= '<div class="btn-wrap">';
                            $res .= '<div>';
                                $res .= '<a href="'.get_sub_field('first_button_link').'">'.get_sub_field('first_button_text').'</a>';
                                $res .= '<div class="btn-hint">'.get_sub_field('first_button_hint').'</div>';
                            $res .= '</div>';
                            $res .= '<div>';
                                $res .= '<a href="'.get_sub_field('second_button_link').'">'.get_sub_field('second_button_text').'</a>';
                                $res .= '<div class="btn-hint">'.get_sub_field('second_button_hint').'</div>';
                            $res .= '</div>';
                        $res .= '</div>';
                        $res .= '<a href="tel:'.get_sub_field('phone_item').'" class="item-phone">'.get_sub_field('phone_item').'</a>';
                    $res .= '</div>';
                $res .= '</div>';

            endwhile;

        endif;

	    $res .= '</div>';
		return sprintf( $res );
	}
}

new SIMP_Restaurant;
